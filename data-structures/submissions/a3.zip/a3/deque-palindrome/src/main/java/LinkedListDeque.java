import java.util.LinkedList;

// Not 100% confident with my own implementation of LinkedListDeque so I will use Java's

public class LinkedListDeque<T> extends LinkedList<T> implements Deque<T> {}
