public enum CommandWord {
    QUIT, HELP, GO, UNKNOWN, LOOK, BACK;
}
