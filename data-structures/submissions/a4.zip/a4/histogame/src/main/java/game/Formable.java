package game;

public interface Formable<T> {
    public boolean canForm(T other);
}